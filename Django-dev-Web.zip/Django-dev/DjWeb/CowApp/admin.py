from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(CowDry)
admin.site.register(keyValues)
admin.site.register(kickOffs)
admin.site.register(milkDuration)
admin.site.register(SMMBT)

