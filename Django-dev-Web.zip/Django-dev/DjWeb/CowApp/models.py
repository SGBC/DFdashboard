from django.db import models

# Create your models here.
class CowDry(models.Model): 
    Animal_Id = models.IntegerField(null=False)
    avg_milk_yield = models.FloatField(null=False)
    avg_Nr_of_milkings = models.FloatField(null=False)
    avg_Milk_duration = models.FloatField(null=False)
    Days_In_Milk = models.IntegerField(null=False)

def __str__(self):
    return (self.Animal_Id)

class keyValues(models.Model):
    avg_daily_milk_per_cow = models.FloatField(null=False)
    avg_daily_nr_of_milkings_per_cow = models.FloatField(null=False)
    nr_of_milkings_cows_yesterday = models.IntegerField()
    avg_milk_from_vms_1 = models.FloatField()
    avg_milk_from_vms_2 = models.FloatField()
    avg_milk_from_vms_1_and_2 = models.FloatField()
    avg_nr_pass_smartgate = models.FloatField()
    projected_monthly_milk = models.FloatField()
    avg_nr_of_kickOffs = models.FloatField()
    avg_time_in_robot = models.FloatField()
    Milk_to_tank_yesterday = models.FloatField()
    cows_lactation_day_0_100 = models.IntegerField()
    cows_lactation_day_101_200 = models.IntegerField()
    cows_lactation_day_201 = models.IntegerField()
    avg_milking_volume_lact_0_100 = models.FloatField()
    avg_milking_volume_lact_101_200 = models.FloatField()
    avg_milking_volume_lact_201 = models.FloatField()
    
def __str__(self):
    return (self.keyValues)


class kickOffs(models.Model):
    Date = models.DateField(auto_now=False, auto_now_add=False)
    Animal_ID = models.IntegerField(null=False)
    Total_milk_yield =  models.FloatField(null=False)
    Nr_of_milkings = models.IntegerField(null=False)
    avg_Milk_duration = models.IntegerField(null=False)
    Nr_of_kickOffs = models.IntegerField(null=False)
    Days_In_Milk = models.IntegerField(null=False)

def __str__(self):
    return (self.kickOffs)

class milkDuration(models.Model):
    Date = models.DateField(auto_now=False, auto_now_add=False)
    Animal_ID = models.IntegerField(null=False)
    Total_milk_yield = models.FloatField(null=False)
    Nr_of_milkings = models.IntegerField(null=False)
    avg_Milk_duration = models.FloatField(null=False)
    Nr_of_kickOffs = models.IntegerField(null=False)
    Days_In_Milk =  models.IntegerField(null=False)

def __str__(self):
    return (self.milkDuration)

class SMMBT(models.Model): # model name is the abrivation of csv file table 
    Date = models.DateField(auto_now=False, auto_now_add=False)
    Animal_ID = models.IntegerField(null=False)
    Total_milk_yield = models.FloatField(null=False)
    Nr_of_milkings = models.IntegerField(null=False)

def __str__(self):
    return (self.Date)

class Meta:
    delimiter = ","

       