from django.urls import path
from . import views 

urlpatterns = [
    path('', views.CowApp, name = 'CowApp'),
    path('AboutGiga', views.AboutGiga, name = 'AboutGiga'), 
    path('contact', views.contact, name = 'contact'),
    path('base', views.base, name="base"),
    path('dashboard', views.dashboard, name = "dashboard"),
    path('login', views.login, name = "login"), 
    path('logout', views.logout, name = "logout"),
    path('calendar', views.calendar, name = "calendar"),
    path('details', views.details, name = "details"), 
    path('register', views.register, name = "register")
    
    
]
