from django.shortcuts import render, redirect 
from django.http import HttpResponse
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages 

# Create your views here.
def register(request):
    if request.method=="POST":
       registration_form = UserCreationForm(request.POST)
       if registration_form.is_valid():
           registration_form.save()
           messages.success(request, ("Your Account is Created"))
           return redirect('home')

    else:

        registration_form = UserCreationForm()
    return render(request, 'register.html', {'registration_form':registration_form})


def CowApp(request):
    context = {
        'welcome_text': 'welcome to Giga WebApp',
    }
    return render(request, 'home.html', {}) # contents are always displayed in the form of dictionary

def AboutGiga(request):
    context = {
        'AboutGiga_text': 'welcome to Giga About Page',
    }
    return render(request, 'AboutGiga.html', {})

def contact(request):
    context = {
        'contact_text': 'welcome to contact us page',
    }
    return render(request, 'contact.html', {})

def base(request):
    context = {
        'base_text': 'Main page of the web',
    }
    return render(request, 'base.html', {})

def dashboard(request):
    context = {
        'dashboard_text': 'Welcome to the Dashboard',
    }
    return render(request, 'dashboard.html', {})

def login(request):
    context = {
        'login_text': 'login.html',
        
    }
    return render(request, 'login.html', {})


def logout(request):
    context = {
        'logout_text': 'logout.html',
        
    }
    return render(request, 'logout.html', {})

def calendar(request):
    context = {
        'login_text': 'calendar.html',
        
    }
    return render(request, 'calendar.html', {})

def details(request):
    context = {
        'login_text': 'details.html',
        
    }
    return render(request, 'details.html', {})