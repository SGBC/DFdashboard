from django.apps import AppConfig


class CowappConfig(AppConfig):
    name = 'CowApp'
