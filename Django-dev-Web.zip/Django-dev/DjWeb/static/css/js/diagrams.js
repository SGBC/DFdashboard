/* here is the js file for diagrams */

/* Plot 1
avg_milk_vm: includes the values 'avg_milk_vm1', 'avg_milk_vm_2', 'avg_milk_vm_all'
*/